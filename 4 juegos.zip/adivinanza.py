import tkinter as tk
import random
import math
import tkinter.messagebox as messagebox  # Se agrega el import para messagebox

def generar_operacion():
    operaciones = ['+', '-', '*', '/', '**', 'sqrt', '%', '//', 'log', 'abs', 'cbrt', 'factorial', 'dot']
    operacion = random.choice(operaciones)
    num1 = random.randint(1, 20)
    num2 = random.randint(1, 20)

    if operacion == '+': nombre_operacion = "Suma"
    elif operacion == '-': nombre_operacion = "Resta"
    elif operacion == '*': nombre_operacion = "Multiplicación"
    elif operacion == '/': nombre_operacion = "División"
    elif operacion == '**': nombre_operacion = "Potencia"
    elif operacion == 'sqrt': nombre_operacion = "Raíz cuadrada"; num1 = random.randint(1, 100)
    elif operacion == '%': nombre_operacion = "Módulo"
    elif operacion == '//': nombre_operacion = "División entera"
    elif operacion == 'log': nombre_operacion = "Logaritmo"
    elif operacion == 'abs': nombre_operacion = "Valor absoluto"
    elif operacion == 'cbrt': nombre_operacion = "Raíz cúbica"
    elif operacion == 'factorial': nombre_operacion = "Factorial"; num1 = random.randint(1, 6)
    elif operacion == 'dot': nombre_operacion = "Producto punto"; num2 = random.randint(1, 5)

    opciones = [nombre_operacion]
    while len(opciones) < 3:
        respuesta_falsa = random.choice(["Suma", "Resta", "Multiplicación", "División", "Potencia", "Raíz cuadrada", "Módulo", "División entera", "Logaritmo", "Valor absoluto", "Raíz cúbica", "Factorial", "Producto punto"])
        if respuesta_falsa != nombre_operacion: opciones.append(respuesta_falsa)
    random.shuffle(opciones)
    return num1, num2, operacion, opciones, nombre_operacion

def verificar_respuesta(opcion_seleccionada, respuesta_correcta):
    global puntaje
    if opcion_seleccionada == respuesta_correcta:
        puntaje += 1
        mensaje_label.config(text="¡Correcto!", fg='green')
    else:
        mensaje_label.config(text="Incorrecto.", fg='red')
    root.after(1000, nueva_operacion)

def nueva_operacion():
    num1, num2, operacion, opciones, nombre_operacion = generar_operacion()
    operacion_label.config(text=f"{num1} {operacion} {num2} = ?")
    for i, boton in enumerate(botones):
        boton.config(text=opciones[i], bg="#5BC0DE", command=lambda i=i: verificar_respuesta(opciones[i], nombre_operacion))
    mensaje_label.config(text="")

def finalizar_juego():
    frame_juego.pack_forget()
    frame_resultado.pack(pady=20)
    resultado_label.config(text=f"Tu puntaje final: {puntaje}")

def reiniciar_juego():
    global puntaje
    puntaje = 0
    frame_resultado.pack_forget()
    frame_juego.pack(pady=20)
    nueva_operacion()

def regresar_inicio():
    frame_resultado.pack_forget()
    frame_inicio.pack(pady=20)

def mostrar_juego():
    global puntaje
    puntaje = 0
    frame_inicio.pack_forget()
    frame_juego.pack(pady=20)
    nueva_operacion()

root = tk.Tk()
root.title("Juego de Adivinanza de Operaciones")
root.geometry("500x500")
root.config(bg="#A7D8F2")

puntaje = 0

frame_inicio = tk.Frame(root, bg="#A7D8F2")
tk.Button(frame_inicio, text="Jugar", font=("Arial", 14), bg="#5BC0DE", fg="white", command=mostrar_juego).pack(pady=10)
tk.Button(frame_inicio, text="Operaciones Des.", font=("Arial", 14), bg="#5BC0DE", fg="white", command=lambda: mostrar_descripciones()).pack(pady=10)  # Se agrega la acción
frame_inicio.pack(pady=20)

frame_juego = tk.Frame(root, bg="#A7D8F2")
operacion_label = tk.Label(frame_juego, text="", font=("Arial", 18), bg="#A7D8F2")
operacion_label.pack(pady=20)
botones = [tk.Button(frame_juego, font=("Arial", 14), width=20, bg="#5BC0DE", fg="white") for _ in range(3)]
for boton in botones: boton.pack(pady=10)
tk.Button(frame_juego, text="Finalizar", font=("Arial", 14), bg="red", fg="white", command=finalizar_juego).pack(pady=10)
mensaje_label = tk.Label(frame_juego, text="", font=("Arial", 14), bg="#A7D8F2")
mensaje_label.pack(pady=10)

frame_resultado = tk.Frame(root, bg="#A7D8F2")
resultado_label = tk.Label(frame_resultado, text="", font=("Arial", 18), bg="#A7D8F2")
resultado_label.pack(pady=20)
tk.Button(frame_resultado, text="Reintentar", font=("Arial", 14), bg="#5BC0DE", fg="white", command=reiniciar_juego).pack(pady=10)
tk.Button(frame_resultado, text="Volver al inicio", font=("Arial", 14), bg="#5BC0DE", fg="white", command=regresar_inicio).pack(pady=10)

def mostrar_descripciones():
    descripcion = """
    Operaciones disponibles:
    - Suma: Añadir dos números.
    - Resta: Sustraer un número de otro.
    - Multiplicación: Multiplicar dos números.
    - División: Dividir un número por otro.
    - Potencia: Elevar un número a una potencia.
    - Raíz cuadrada: Extraer la raíz cuadrada de un número.
    - Módulo: Obtener el residuo de una división.
    - División entera: División sin decimales.
    - Logaritmo: Obtener el logaritmo de un número.
    - Valor absoluto: Obtener el valor absoluto de un número.
    - Raíz cúbica: Extraer la raíz cúbica de un número.
    - Factorial: Calcular el factorial de un número.
    - Producto punto: Calcular el producto punto entre dos vectores.
    """
    messagebox.showinfo("Operaciones Descripción", descripcion)  # Se usa messagebox para mostrar la descripción

root.mainloop()
