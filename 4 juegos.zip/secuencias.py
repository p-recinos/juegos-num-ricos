import tkinter as tk
from tkinter import messagebox

# Funciones para los patrones de secuencia
def secuencia_doble():
    return [2**i for i in range(1, 6)]

def secuencia_fibonacci():
    fib = [0, 1]
    for i in range(2, 6):
        fib.append(fib[-1] + fib[-2])
    return fib[1:]

def secuencia_potencias():
    return [3**i for i in range(1, 6)]

# Función para verificar la respuesta
def verificar_respuesta():
    respuesta_usuario = entrada_usuario.get()
    try:
        respuesta_usuario = [int(x) for x in respuesta_usuario.split(',')]
    except ValueError:
        messagebox.showerror("Error", "Por favor ingrese una secuencia de números válida")
        return

    if respuesta_usuario == secuencia_correcta:
        messagebox.showinfo("¡Correcto!", "¡Bien hecho! Has completado la secuencia correctamente.")
    else:
        messagebox.showerror("Incorrecto", "La secuencia no es correcta. Inténtalo de nuevo.")

# Configuración de la ventana principal
root = tk.Tk()
root.title("Juego de Secuencia Numérica")
root.geometry("400x300")

# Etiquetas de instrucciones
label_instrucciones = tk.Label(root, text="Introduce la secuencia siguiente:")
label_instrucciones.pack(pady=20)

# Cuadro para la secuencia
secuencia_label = tk.Label(root, text="", font=("Arial", 14))
secuencia_label.pack(pady=10)

# Entrada del usuario
entrada_usuario = tk.Entry(root, font=("Arial", 12))
entrada_usuario.pack(pady=10)

# Botón para verificar la respuesta
boton_verificar = tk.Button(root, text="Verificar", command=verificar_respuesta)
boton_verificar.pack(pady=20)

# Función para generar una secuencia aleatoria
def generar_secuencia():
    import random
    global secuencia_correcta
    patron = random.choice([secuencia_doble, secuencia_fibonacci, secuencia_potencias])
    secuencia_correcta = patron()
    secuencia_label.config(text=", ".join(map(str, secuencia_correcta[:-1])) + ", ?")

# Generar la secuencia inicial
generar_secuencia()

# Botón para generar una nueva secuencia
boton_nueva_secuencia = tk.Button(root, text="Nueva Secuencia", command=generar_secuencia)
boton_nueva_secuencia.pack(pady=10)

# Ejecutar la interfaz gráfica
root.mainloop()
