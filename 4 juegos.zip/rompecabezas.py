import tkinter as tk
import random
import time

# Lista de colores para los cuadros, asegurándonos de que cada uno sea único
colores = [
    "#FF5733", "#33FF57", "#3357FF", "#F1C40F", "#9B59B6", "#1F618D", "#E74C3C", 
    "#D35400", "#16A085", "#7D3C98", "#F39C12", "#27AE60", "#2980B9", "#8E44AD", 
    "#E67E22", "#FF1493"
]

# Función para mezclar y generar los números en el tablero
def generar_tablero():
    tablero = list(range(1, 16)) + [None]
    random.shuffle(tablero)
    return [tablero[i:i + 4] for i in range(0, 16, 4)]

# Función para actualizar la interfaz
def actualizar_tablero():
    color_idx = 0
    for i in range(4):
        for j in range(4):
            num = tablero[i][j]
            if num is not None:
                botones[i][j].config(text=str(num), bg=colores[color_idx], fg="white", font=("Arial", 18))
                color_idx += 1
            else:
                botones[i][j].config(text="", bg="#A7D8F2")
            botones[i][j].grid(row=i, column=j, padx=5, pady=5)

# Función para mover una pieza en el tablero
def mover_pieza(i, j):
    global puntaje
    # Encuentra la posición del espacio vacío
    empty_i, empty_j = next((x, y) for x in range(4) for y in range(4) if tablero[x][y] is None)
    
    # Verifica si el movimiento es válido
    if (abs(i - empty_i) == 1 and j == empty_j) or (i == empty_i and abs(j - empty_j) == 1):
        # Verifica si la pieza está en su lugar correcto
        if tablero[i][j] == solucion[i][j]:
            puntaje += 10  # Sumar puntos por movimiento correcto
        else:
            puntaje -= 5  # Restar puntos por movimiento incorrecto
        # Intercambia la pieza con el espacio vacío
        tablero[empty_i][empty_j], tablero[i][j] = tablero[i][j], tablero[empty_i][empty_j]
        actualizar_tablero()
        if comprobar_ganador():
            finalizar_juego("¡Ganaste!", "¡Felicidades, resolviste el rompecabezas!")
    else:
        puntaje -= 2  # Restar puntos por movimiento no válido

# Función para verificar si el tablero está resuelto
def comprobar_ganador():
    solucion_flat = [solucion[i][j] for i in range(4) for j in range(4)]
    tablero_flat = [tablero[i][j] for i in range(4) for j in range(4)]
    return tablero_flat == solucion_flat

# Función para finalizar el juego
def finalizar_juego(titulo, mensaje):
    global tiempo_inicio
    tiempo_total = int(time.time() - tiempo_inicio)  # Tiempo transcurrido en segundos
    tiempo_label.config(text=f"Tiempo: {tiempo_total} segundos")
    mensaje_final.config(text=mensaje, fg="red")
    boton_reiniciar.pack(pady=10)
    puntaje_final = puntaje + 100 if comprobar_ganador() else puntaje  # Sumar 100 puntos si se resuelve correctamente
    puntaje_label.config(text=f"Puntaje final: {puntaje_final}")
    mensaje_final.pack(pady=10)

# Función para reiniciar el juego
def reiniciar_juego():
    global tablero, puntaje, tiempo_inicio, solucion
    puntaje = 0
    tablero = generar_tablero()
    solucion = [list(range(i * 4 + 1, (i + 1) * 4 + 1)) for i in range(4)]  # Solución del tablero
    solucion[3][3] = None  # El último espacio es vacío
    actualizar_tablero()
    puntaje_label.config(text=f"Puntaje: {puntaje}")
    mensaje_final.config(text="")
    boton_reiniciar.pack_forget()
    tiempo_inicio = time.time()  # Reiniciar el tiempo
    actualizar_tablero()

# Interfaz gráfica
root = tk.Tk()
root.title("Rompecabezas de Números")
root.geometry("500x600")
root.config(bg="#FFDDC1")

puntaje = 0

# Crear el marco principal
frame = tk.Frame(root, bg="#FFDDC1")
frame.pack(pady=20)

# Crear los botones del tablero
tablero = generar_tablero()
solucion = [list(range(i * 4 + 1, (i + 1) * 4 + 1)) for i in range(4)]  # Solución del tablero
solucion[3][3] = None  # El último espacio es vacío
botones = [[None for _ in range(4)] for _ in range(4)]
for i in range(4):
    for j in range(4):
        botones[i][j] = tk.Button(frame, font=("Arial", 18), width=4, height=2, bg="#5BC0DE", fg="white", command=lambda i=i, j=j: mover_pieza(i, j))
        botones[i][j].grid(row=i, column=j, padx=5, pady=5)

# Etiqueta de tiempo
tiempo_label = tk.Label(root, text="Tiempo: 0 segundos", font=("Arial", 14), bg="#FFDDC1")
tiempo_label.pack(pady=10)

# Etiqueta de puntaje
puntaje_label = tk.Label(root, text=f"Puntaje: {puntaje}", font=("Arial", 14), bg="#FFDDC1")
puntaje_label.pack(pady=10)

# Mensaje final
mensaje_final = tk.Label(root, text="", font=("Arial", 16), bg="#FFDDC1")

# Botón de reiniciar
boton_reiniciar = tk.Button(root, text="Reiniciar", font=("Arial", 14), bg="#5BC0DE", fg="white", command=reiniciar_juego)

# Iniciar el contador
tiempo_inicio = time.time()  # Registrar el tiempo de inicio del juego

# Ejecutar la interfaz
root.mainloop()
