import tkinter as tk
import random
from threading import Timer

# Función para generar una operación aleatoria
def generar_operacion(dificultad):
    operaciones = ['+', '-', '*', '/']
    operacion = random.choice(operaciones)
    
    if dificultad == 'facil':
        num1 = random.randint(1, 10)
        num2 = random.randint(1, 10)
    elif dificultad == 'normal':
        num1 = random.randint(10, 50)
        num2 = random.randint(1, 50)
    else:  # Dificultad difícil
        num1 = random.randint(50, 100)
        num2 = random.randint(1, 100)
    
    # Asegurarse de no dividir por 0
    if operacion == '/':
        num2 = random.randint(1, num1)
        resultado = num1 / num2
    elif operacion == '+':
        resultado = num1 + num2
    elif operacion == '-':
        resultado = num1 - num2
    else:  # Multiplicación
        resultado = num1 * num2
    
    return f"{num1} {operacion} {num2}", resultado

# Función para manejar cada operación
def siguiente_operacion(dificultad):
    global operacion_num, timer, puntaje, respuesta_correcta
    if operacion_num < 5:  # Limitar a 5 operaciones
        pregunta, respuesta = generar_operacion(dificultad)
        operacion_num += 1
        operacion_label.config(text=pregunta)
        respuesta_correcta[0] = respuesta  # Guardar la respuesta correcta
        
        # Iniciar el temporizador
        timer = Timer(6, tiempo_limite)
        timer.start()
        
        # Función para verificar la respuesta al presionar Enter
        def verificar_respuesta(event=None):
            global puntaje
            try:
                user_answer = float(entry_respuesta.get())
                if abs(user_answer - respuesta) < 0.01:  # Comparación con margen
                    resultado_label.config(text="¡Respuesta correcta!")
                    puntaje += 1  # Aumentar el puntaje
                else:
                    resultado_label.config(text="¡Respuesta incorrecta!")
            except ValueError:
                resultado_label.config(text="Por favor ingrese un número válido.")
            
            entry_respuesta.delete(0, tk.END)  # Limpiar campo de entrada
            # Esperar 1 segundo antes de ir a la siguiente operación
            timer.cancel()  # Cancelar el temporizador cuando el usuario responde
            Timer(1, lambda: siguiente_operacion(dificultad)).start()  # Cambiar operación tras 1 segundo

        # Asociar la tecla "Enter" con la función de verificar respuesta
        entry_respuesta.bind("<Return>", verificar_respuesta)
    else:
        # Mostrar el puntaje al final
        resultado_label.config(text=f"Juego Terminado. Puntaje final: {puntaje}/5")
        mostrar_retry_button()  # Mostrar el botón de reinicio del juego
        mostrar_return_home_button()  # Mostrar el botón de regreso a la página principal

# Función para manejar el tiempo límite
def tiempo_limite():
    resultado_label.config(text="¡Tiempo agotado!")
    entry_respuesta.delete(0, tk.END)  # Limpiar el campo de respuesta
    # Avanzar a la siguiente operación después de 1 segundo
    if operacion_num < 5:
        Timer(1, lambda: siguiente_operacion(dificultad_seleccionada.get())).start()

# Función para crear la ventana emergente de selección de dificultad
def ventana_dificultad():
    global ventana_dificultad_frame
    
    ventana_dificultad_frame = tk.Toplevel(root)
    ventana_dificultad_frame.title("Selecciona la dificultad")
    ventana_dificultad_frame.geometry("300x250")  # Tamaño más pequeño
    
    dificultad_label = tk.Label(ventana_dificultad_frame, text="Selecciona la dificultad:", font=('Helvetica', 16))
    dificultad_label.pack(pady=20)

    # Establecer dificultad por defecto en "facil"
    dificultad_var.set('facil')

    facil_button = tk.Radiobutton(ventana_dificultad_frame, text="Fácil", variable=dificultad_var, value="facil", font=('Helvetica', 14))
    facil_button.pack(pady=5)

    normal_button = tk.Radiobutton(ventana_dificultad_frame, text="Normal", variable=dificultad_var, value="normal", font=('Helvetica', 14))
    normal_button.pack(pady=5)

    dificil_button = tk.Radiobutton(ventana_dificultad_frame, text="Difícil", variable=dificultad_var, value="dificil", font=('Helvetica', 14))
    dificil_button.pack(pady=5)

    # Botón para confirmar la dificultad seleccionada
    confirmar_button = tk.Button(ventana_dificultad_frame, text="Aplicar cambios", command=aplicar_cambios, bg="#FF9800", fg="white", font=('Helvetica', 14), width=15, height=2)
    confirmar_button.pack(pady=20)

# Función para aplicar los cambios y regresar
def aplicar_cambios():
    global dificultad_seleccionada
    dificultad = dificultad_var.get()  # Obtener el valor de la dificultad seleccionada
    dificultad_seleccionada.set(dificultad)  # Establecer la dificultad en la variable global
    ventana_dificultad_frame.destroy()  # Cerrar la ventana de dificultad
    pantalla_principal.pack()  # Regresar a la pantalla principal

# Función para iniciar el juego
def iniciar_juego():
    dificultad = dificultad_seleccionada.get()  # Obtener la dificultad seleccionada
    pantalla_principal.pack_forget()  # Ocultar la pantalla principal
    iniciar_pantalla_juego(dificultad)  # Iniciar el juego con la dificultad seleccionada

# Función para iniciar el juego con dificultad seleccionada
def iniciar_pantalla_juego(dificultad):
    global puntaje, operacion_num, respuesta_correcta, dificultad_seleccionada
    puntaje = 0
    operacion_num = 0
    operacion_label.pack(pady=30)
    entry_respuesta.pack(pady=10)
    verificar_button.config(state=tk.NORMAL)
    resultado_label.pack(pady=20)
    siguiente_operacion(dificultad)  # Comienza la primera operación

# Función para regresar a la pantalla principal
def regresar_pantalla_principal():
    global puntaje, operacion_num
    puntaje = 0
    operacion_num = 0
    operacion_label.pack_forget()
    entry_respuesta.pack_forget()
    verificar_button.config(state=tk.DISABLED)
    resultado_label.pack_forget()
    pantalla_principal.pack()  # Volver a mostrar la pantalla principal

# Función para mostrar el botón de reiniciar el juego
def mostrar_retry_button():
    retry_button.pack(pady=20)  # Mostrar el botón de reiniciar

# Función para reiniciar el juego
def retry_game():
    global puntaje, operacion_num
    puntaje = 0
    operacion_num = 0
    retry_button.pack_forget()  # Ocultar el botón de reiniciar
    operacion_label.pack(pady=30)
    entry_respuesta.pack(pady=10)
    verificar_button.config(state=tk.NORMAL)
    resultado_label.pack(pady=20)
    siguiente_operacion(dificultad_seleccionada.get())  # Reiniciar el juego con la misma dificultad

# Función para mostrar el botón de regresar a la página principal
def mostrar_return_home_button():
    return_home_button.pack(pady=20)  # Mostrar el botón de regresar a la página principal

# Función para regresar a la pantalla principal desde el juego
def return_home():
    global puntaje, operacion_num
    puntaje = 0
    operacion_num = 0
    return_home_button.pack_forget()  # Ocultar el botón de regresar
    retry_button.pack_forget()  # Ocultar el botón de reiniciar
    operacion_label.pack_forget()  # Ocultar la operación
    entry_respuesta.pack_forget()  # Ocultar la entrada de respuesta
    resultado_label.pack_forget()  # Ocultar el resultado
    pantalla_principal.pack()  # Volver a la pantalla principal

# Interfaz gráfica
root = tk.Tk()
root.title("Juego Matemático")

# Ajustes de tamaño de la ventana
root.geometry("700x500")

# Pantalla de inicio con botones
pantalla_principal = tk.Frame(root)

# Botón de jugar
jugar_button = tk.Button(pantalla_principal, text="Jugar", command=iniciar_juego, bg="#4CAF50", fg="white", font=('Helvetica', 18), width=20, height=2)
jugar_button.pack(pady=20)

# Botón de dificultad
dificultad_button = tk.Button(pantalla_principal, text="Dificultad", command=ventana_dificultad, bg="#2196F3", fg="white", font=('Helvetica', 18), width=20, height=2)
dificultad_button.pack(pady=20)

pantalla_principal.pack()

# Pantalla del juego
operacion_label = tk.Label(root, text="", font=('Helvetica', 24), width=20, height=2)
entry_respuesta = tk.Entry(root, font=('Helvetica', 18), width=15)
verificar_button = tk.Button(root, text="Verificar Respuesta", state=tk.DISABLED)
resultado_label = tk.Label(root, text="", font=('Helvetica', 18))

# Botón de regresar
regresar_button = tk.Button(root, text="Regresar", command=regresar_pantalla_principal, bg="#FF5722", fg="white", font=('Helvetica', 14), width=15, height=2)

# Botón de reiniciar juego
retry_button = tk.Button(root, text="Reintentar Juego", command=retry_game, bg="#FF5722", fg="white", font=('Helvetica', 14), width=20, height=2)

# Botón de regresar a la página principal
return_home_button = tk.Button(root, text="Volver a la Página Principal", command=return_home, bg="#FFC107", fg="white", font=('Helvetica', 14), width=20, height=2)

# Variables globales para almacenar la respuesta correcta
respuesta_correcta = [0]

# Variables globales para el puntaje y operaciones
puntaje = 0
operacion_num = 0

# Variable global para dificultad seleccionada
dificultad_seleccionada = tk.StringVar()

# Variable global para seleccionar dificultad
dificultad_var = tk.StringVar()

# Iniciar la ventana principal
root.mainloop()
